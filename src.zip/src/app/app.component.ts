import { Component } from '@angular/core';

import { Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import {LocalStorageService} from './services/local-storage.service';
import {UserServiceService} from './services/user-service.service';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html'
})
export class AppComponent {
  public appPages = [
    {title: '返回首页', url: '/home', icon: 'chatboxes'},
    {title: '添加商品', url: '/addProduct', icon: 'create'},
    {title: '商品列表', url: '/productList', icon: 'git-merge'},
    {title: '所有分类', url: '/categoryList', icon: 'cash'},
    {title: '关于我们', url: '/aboutus', icon: 'cash'},
    {title: '店铺设置', url: '/shop', icon: 'cash'},
  ];
  public userCofig:any;

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private userService: UserServiceService
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
    // 取当前登录用户信息
    this.userCofig = this.userService.getUser();
    console.log(this.userCofig);
  }
}
