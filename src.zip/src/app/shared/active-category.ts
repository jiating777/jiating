export class ActiveCategory {
  id: number;
  name: string;
}
