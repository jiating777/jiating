export class Category {
  id: number;
  name: string;
  children: Array<Category>;
  // children: Category[];
}

