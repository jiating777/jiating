import { Category } from './category';
export const CATEGORIES: Category[] = [
  {
    id: 1,
    name: '手机/配件',
    children: [
      {
        id: 11,
        name: '华为',
        children: []
      },
      {
        id: 12,
        name: '小米',
        children: []
      },
      {
        id: 13,
        name: '苹果',
        children: []
      }
    ]
  },
  {
    id: 2,
    name: '游戏设备',
    children: [
      {
        id: 21,
        name: '鼠标',
        children: []
      },
      {
        id: 22,
        name: '键盘',
        children: []
      }
    ]
  },
  {
    id: 3,
    name: '相机摄影',
    children: [
      {
        id: 31,
        name: '单反相机',
        children: []
      },
      {
        id: 32,
        name: '镜头',
        children: []
      },
      {
        id: 33,
        name: '微单相机',
        children: []
      }
    ]
  },
  {
    id: 4,
    name: '影音/智能',
    children: [
      {
        id: 41,
        name: '耳机',
        children: []
      },
      {
        id: 42,
        name: '智能手环',
        children: []
      },
      {
        id: 43,
        name: '音箱',
        children: []
      },
      {
        id: 44,
        name: '投影仪',
        children: []
      }
    ]
  },
  {
    id: 5,
    name: '默认类别',
    children: []
  }
];
